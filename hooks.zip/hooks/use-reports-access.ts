'use client'

import { useState } from "react";
import type { ReportRole } from "types";
import { REPORT_TABS, REPORT_ROLE_TABS } from "config";

export interface UseReportsAccessReturn {
    role: ReportRole;
    setRole: (role: ReportRole) => void;
    tabs: typeof REPORT_TABS;
    can: (roles: ReportRole[]) => boolean;
}

export function useReportsAccess(): UseReportsAccessReturn {
    const [role, setRole] = useState<ReportRole>("owner")
    const allowedTabIds = REPORT_ROLE_TABS[role]
    const tabs = REPORT_TABS.filter((tab) => allowedTabIds.includes(tab.id))

    const can = (roles: ReportRole[]) => {
        return roles.includes(role)
    }

    return {
        role,
        setRole,
        tabs,
        can
    }
}
